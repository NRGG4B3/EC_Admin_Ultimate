// Using our custom toast provider - sonner is not needed
// This file is kept for compatibility but uses our internal toast system
export function Toaster() {
  return null; // Toast provider is already included in App.tsx
}