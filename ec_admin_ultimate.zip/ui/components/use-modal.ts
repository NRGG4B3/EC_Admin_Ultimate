// Re-export the useModal hook from modal-provider for convenience
export { useModal } from './modal-provider';