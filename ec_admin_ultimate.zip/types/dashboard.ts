export interface DashboardStats { /* fields from API schema */ }
export interface QuickAction { /* fields from API schema */ }
export interface EconomyStats { /* fields from API schema */ }
export interface AdminCategory { /* fields from API schema */ }
// ...repeat for other types files...
