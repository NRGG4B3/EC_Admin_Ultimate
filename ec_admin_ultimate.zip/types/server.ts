export interface ServerInfo {
  name: string;
  hostname: string;
  maxClients: number;
  onlinePlayers: number;
  // Add more fields as needed from your API schema
}
