declare module 'lucide-react';
declare module 'lucide-react' {
	const content: any;
	export = content;
}
