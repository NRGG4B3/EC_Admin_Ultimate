--[[ NRG API - Marketplace Sync (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/marketplace-sync.lua loaded (NUI callbacks disabled)')
return
