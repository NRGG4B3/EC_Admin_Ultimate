--[[ NRG API - Vehicle Registry (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/vehicle-registry.lua loaded (NUI callbacks disabled)')
return
