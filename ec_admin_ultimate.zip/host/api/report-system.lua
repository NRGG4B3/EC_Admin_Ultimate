--[[
    EC Admin Ultimate - Host API: Report System
    Player report system
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/report-system.lua loaded (NUI callbacks disabled)')
return