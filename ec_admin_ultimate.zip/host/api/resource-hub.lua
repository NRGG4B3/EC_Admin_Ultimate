--[[ NRG API - Resource Hub (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/resource-hub.lua loaded (NUI callbacks disabled)')
return
