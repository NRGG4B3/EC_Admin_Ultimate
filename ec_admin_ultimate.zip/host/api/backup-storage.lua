--[[ NRG API - Backup Storage (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/backup-storage.lua loaded (NUI callbacks disabled)')
return
