--[[ NRG API - Player Tracking (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/player-tracking.lua loaded (NUI callbacks disabled)')
return
