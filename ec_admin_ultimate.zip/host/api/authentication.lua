--[[
    EC Admin Ultimate - Host API: Authentication
    SSO & centralized admin authentication
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/authentication.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return