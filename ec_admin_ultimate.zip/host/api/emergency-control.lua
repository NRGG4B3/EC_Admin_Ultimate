--[[ NRG API - Emergency Control (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/emergency-control.lua loaded (NUI callbacks disabled)')
return
