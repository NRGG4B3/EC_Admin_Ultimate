--[[ NRG API - Global Chat (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/global-chat.lua loaded (NUI callbacks disabled)')
return
