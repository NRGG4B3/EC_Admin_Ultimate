--[[ NRG API - Anticheat Sync (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/anticheat-sync.lua loaded (NUI callbacks disabled)')
return
