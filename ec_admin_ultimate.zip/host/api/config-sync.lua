--[[
    EC Admin Ultimate - Host API: Config Sync
    Configuration synchronization
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/config-sync.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return