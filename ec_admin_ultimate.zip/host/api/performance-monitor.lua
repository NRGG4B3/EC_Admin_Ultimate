--[[
    EC Admin Ultimate - Host API: Performance Monitor
    Real-time performance monitoring
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/performance-monitor.lua loaded (NUI callbacks disabled)')
return