--[[ NRG API - Screenshot Storage (DISABLED - RegisterNUICallback not supported on server) ]]
Logger.Info('host/api/screenshot-storage.lua loaded (NUI callbacks disabled)')
return
