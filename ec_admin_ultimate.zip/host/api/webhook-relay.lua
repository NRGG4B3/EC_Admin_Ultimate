--[[
    EC Admin Ultimate - Host API: Webhook Relay
    Centralized Discord webhook relay
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/webhook-relay.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return