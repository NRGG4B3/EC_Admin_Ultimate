--[[
    EC Admin Ultimate - Host API: Audit Logging
    Comprehensive audit trail
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/audit-logging.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return