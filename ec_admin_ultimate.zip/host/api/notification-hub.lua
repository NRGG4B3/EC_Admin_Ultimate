--[[
    EC Admin Ultimate - Host API: Notification Hub
    Push notifications
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/notification-hub.lua loaded (NUI callbacks disabled)')
return