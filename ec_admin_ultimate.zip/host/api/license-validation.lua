--[[
    EC Admin Ultimate - Host API: License Validation
    Central license management for all customer servers
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/license-validation.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return