--[[
    EC Admin Ultimate - Host API: Global Bans
    Global ban synchronization across all customer servers
    DISABLED: RegisterNUICallback is client-side only
]]

Logger.Info('host/api/global-bans.lua loaded (NUI callbacks disabled - use HTTP endpoints)')
return