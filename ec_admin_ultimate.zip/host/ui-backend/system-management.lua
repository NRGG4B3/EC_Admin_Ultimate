-- Host System Management UI Endpoint
return function()
    return { success = true, data = {} }
end