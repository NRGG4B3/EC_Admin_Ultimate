-- Host Jobs & Gangs UI Endpoint
return function()
    return { success = true, data = {} }
end