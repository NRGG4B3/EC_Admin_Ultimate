-- EC Admin Ultimate - Client NUI Callbacks
-- DISABLED: All functionality moved to nui-bridge.lua
-- This file is kept for backwards compatibility but does nothing

Logger.Info('')

-- Everything is handled in nui-bridge.lua which loads FIRST
-- DO NOT re-enable this file as it causes conflicts with RegisterNUICallback
