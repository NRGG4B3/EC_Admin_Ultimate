-- EC Admin Ultimate - Host Control Actions (Client)
-- All RegisterNetEvent handlers for host actions
-- Author: NRG Development
-- Version: 1.0.0

-- This file handles incoming actions from the UI
-- All actions are forwarded to the server for processing

Logger.Info('🏢 Host Control actions loaded')
