-- EC Admin Ultimate - Host API Proxy
-- Forwards /api/host/* requests from FiveM (30120) to localhost:3000
-- Part of Option B architecture: UI on 30120, Host API on localhost:3000

local json = json or require('json')

-- Safety check: Ensure Config exists
if not Config then
    print("^1[EC Admin] Host API proxy ERROR: Config not loaded!^0")
    return
end

-- Only load this proxy if host mode is enabled
if not Config.HostApi or not Config.HostApi.enabled then
    print("^3[EC Admin] Host API proxy disabled (Config.HostApi.enabled = false)^0")
    return
end

print("^2[EC Admin] Loading Host API Proxy...^0")
print("^2[EC Admin] Target: " .. Config.HostApi.baseUrl .. "^0")

-- Forward request to localhost:3000 with security header
local function forwardToHost(method, path, body, callback)
    local url = Config.HostApi.baseUrl .. path
    local headers = {
        ["Content-Type"] = "application/json",
        ["X-Host-Secret"] = Config.HostApi.secret
    }
    
    local data = ""
    if body and type(body) == "table" then
        local success, encoded = pcall(json.encode, body)
        if success then
            data = encoded
        else
            print("^1[EC Admin Proxy] Failed to encode request body: " .. tostring(encoded) .. "^0")
            callback(500, json.encode({ error = "Request encoding failed" }), {})
            return
        end
    elseif body and type(body) == "string" then
        data = body
    end
    
    -- Timeout handling
    local timedOut = false
    local timeoutTimer = SetTimeout(Config.HostApi.timeoutMs or 10000, function()
        if not timedOut then
            timedOut = true
            print("^1[EC Admin Proxy] Request timed out: " .. method .. " " .. path .. "^0")
            callback(504, json.encode({ error = "Gateway timeout" }), {})
        end
    end)
    
    PerformHttpRequest(url, function(statusCode, responseText, responseHeaders)
        if timedOut then
            return -- Already handled by timeout
        end
        
        ClearTimeout(timeoutTimer)
        
        if not statusCode then
            print("^1[EC Admin Proxy] Request failed: " .. method .. " " .. path .. "^0")
            callback(502, json.encode({ error = "Bad gateway - host server unreachable" }), {})
            return
        end
        
        callback(statusCode, responseText or "{}", responseHeaders or {})
    end, method, data, headers)
end

-- Register proxy routes for all /api/host/* endpoints
-- These routes intercept browser requests and forward them to localhost:3000

print("^2[EC Admin] Registering Host API Proxy Routes...^0")

-- GET /api/host/*
SetHttpHandler(function(req, res)
    local path = req.path
    
    -- Only handle /api/host/* routes
    if not path:match("^/api/host/") then
        return false -- Let other handlers process this
    end
    
    if req.method ~= "GET" then
        return false -- Let other handlers process this
    end
    
    print("^3[EC Admin Proxy] GET " .. path .. "^0")
    
    forwardToHost("GET", path, nil, function(statusCode, responseText, responseHeaders)
        res.writeHead(statusCode, {
            ["Content-Type"] = responseHeaders["Content-Type"] or "application/json",
            ["Access-Control-Allow-Origin"] = "*"
        })
        res.send(responseText)
    end)
    
    return true -- We handled this request
end)

-- POST /api/host/*
SetHttpHandler(function(req, res)
    local path = req.path
    
    -- Only handle /api/host/* routes
    if not path:match("^/api/host/") then
        return false -- Let other handlers process this
    end
    
    if req.method ~= "POST" then
        return false -- Let other handlers process this
    end
    
    print("^3[EC Admin Proxy] POST " .. path .. "^0")
    
    local body = {}
    if req.body and #req.body > 0 then
        local success, parsed = pcall(json.decode, req.body)
        if success and type(parsed) == "table" then
            body = parsed
        else
            print("^1[EC Admin Proxy] Failed to parse POST body^0")
        end
    end
    
    forwardToHost("POST", path, body, function(statusCode, responseText, responseHeaders)
        res.writeHead(statusCode, {
            ["Content-Type"] = responseHeaders["Content-Type"] or "application/json",
            ["Access-Control-Allow-Origin"] = "*"
        })
        res.send(responseText)
    end)
    
    return true -- We handled this request
end)

-- PUT /api/host/*
SetHttpHandler(function(req, res)
    local path = req.path
    
    -- Only handle /api/host/* routes
    if not path:match("^/api/host/") then
        return false -- Let other handlers process this
    end
    
    if req.method ~= "PUT" then
        return false -- Let other handlers process this
    end
    
    print("^3[EC Admin Proxy] PUT " .. path .. "^0")
    
    local body = {}
    if req.body and #req.body > 0 then
        local success, parsed = pcall(json.decode, req.body)
        if success and type(parsed) == "table" then
            body = parsed
        end
    end
    
    forwardToHost("PUT", path, body, function(statusCode, responseText, responseHeaders)
        res.writeHead(statusCode, {
            ["Content-Type"] = responseHeaders["Content-Type"] or "application/json",
            ["Access-Control-Allow-Origin"] = "*"
        })
        res.send(responseText)
    end)
    
    return true -- We handled this request
end)

-- DELETE /api/host/*
SetHttpHandler(function(req, res)
    local path = req.path
    
    -- Only handle /api/host/* routes
    if not path:match("^/api/host/") then
        return false -- Let other handlers process this
    end
    
    if req.method ~= "DELETE" then
        return false -- Let other handlers process this
    end
    
    print("^3[EC Admin Proxy] DELETE " .. path .. "^0")
    
    forwardToHost("DELETE", path, nil, function(statusCode, responseText, responseHeaders)
        res.writeHead(statusCode, {
            ["Content-Type"] = responseHeaders["Content-Type"] or "application/json",
            ["Access-Control-Allow-Origin"] = "*"
        })
        res.send(responseText)
    end)
    
    return true -- We handled this request
end)

print("^2[EC Admin] Host API Proxy loaded successfully!^0")
print("^2[EC Admin] Routes: /api/host/* → " .. Config.HostApi.baseUrl .. "/api/host/*^0")
