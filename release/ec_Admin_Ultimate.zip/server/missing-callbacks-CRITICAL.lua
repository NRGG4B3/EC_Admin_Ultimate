--[[
    EC Admin Ultimate - CRITICAL MISSING CALLBACKS
    These callbacks were called by the client but never registered on the server
    This file fixes 26 critical missing callbacks that break the admin panel
]]

print('^3[EC Admin] Loading CRITICAL missing callbacks...^0')

--[[
    In-memory state with lightweight persistence so the callbacks don't lose
    data between restarts. We keep the file within the resource to avoid any
    external dependencies. This is intentionally minimal but reliable enough
    for production servers.
]]
local STATE_FILE = 'runtime-state.json'
local currentResource = GetCurrentResourceName()

local state = {
    settings = {},
    webhooks = {},
    adminMembers = {},
    anticheat = {
        modules = {},
        config = {}
    },
    playerFlags = {},
    transactions = {}
}

local function readState()
    local raw = LoadResourceFile(currentResource, STATE_FILE)
    if not raw or raw == '' then return end

    local ok, decoded = pcall(json.decode, raw)
    if ok and type(decoded) == 'table' then
        state = decoded
        state.settings = state.settings or {}
        state.webhooks = state.webhooks or {}
        state.adminMembers = state.adminMembers or {}
        state.anticheat = state.anticheat or { modules = {}, config = {} }
        state.anticheat.modules = state.anticheat.modules or {}
        state.anticheat.config = state.anticheat.config or {}
        state.playerFlags = state.playerFlags or {}
        state.transactions = state.transactions or {}
    else
        print(('^1[EC Admin] Failed to decode %s: %s^0'):format(STATE_FILE, tostring(decoded)))
    end
end

local function saveState()
    local ok, encoded = pcall(json.encode, state)
    if not ok then
        print('^1[EC Admin] Failed to encode runtime state:^0', encoded)
        return
    end

    SaveResourceFile(currentResource, STATE_FILE, encoded, -1)
end

readState()

-- Framework helpers (kept lightweight to avoid cross-file dependencies)
local function detectFramework()
    if GetResourceState('qb-core') == 'started' then
        return exports['qb-core']:GetCoreObject(), 'qb-core'
    elseif GetResourceState('qbx_core') == 'started' then
        local success, core = pcall(function()
            return exports['qbx_core']:GetCoreObject()
        end)

        if success and core then
            return core, 'qbx'
        end
    elseif GetResourceState('es_extended') == 'started' then
        return exports['es_extended']:getSharedObject(), 'esx'
    end

    return nil, 'standalone'
end

local Framework, FrameworkType = detectFramework()

local function getLicenseIdentifier(playerId)
    for i = 0, GetNumPlayerIdentifiers(playerId) - 1 do
        local identifier = GetPlayerIdentifier(playerId, i)
        if identifier and identifier:find('license:') then
            return identifier
        end
    end

    return ('player:%s'):format(tostring(playerId))
end

local function getMoney(playerId, moneyType)
    if not Framework then return 0 end

    local success, amount = pcall(function()
        if FrameworkType == 'qbx' then
            local player = (Framework.Functions and Framework.Functions.GetPlayer and Framework.Functions.GetPlayer(playerId))
                or (Framework.GetPlayer and Framework.GetPlayer(playerId))

            if not player then return 0 end

            if player.Functions and player.Functions.GetMoney then
                local balance = player.Functions.GetMoney(moneyType)
                if balance ~= nil then return balance end
            end

            if player.PlayerData and player.PlayerData.money then
                return player.PlayerData.money[moneyType] or 0
            end
        elseif FrameworkType == 'qb-core' then
            local player = Framework.Functions.GetPlayer(playerId)
            return player and player.PlayerData.money[moneyType] or 0
        elseif FrameworkType == 'esx' then
            local xPlayer = Framework.GetPlayerFromId(playerId)
            if not xPlayer then return 0 end

            if moneyType == 'cash' or moneyType == 'money' then
                return xPlayer.getMoney() or 0
            elseif moneyType == 'bank' then
                local bank = xPlayer.getAccount('bank')
                return (bank and bank.money) or 0
            end
        end

        return 0
    end)

    if not success then
        print('^1[EC Admin] Failed to fetch player money:^0', amount)
        return 0
    end

    return amount or 0
end

-- Database helpers (detect the active SQL driver and run safe queries)
local function getSqlFetcher()
    if MySQL and MySQL.Sync and type(MySQL.Sync.fetchAll) == 'function' then
        return function(query, params)
            return MySQL.Sync.fetchAll(query, params or {})
        end, 'MySQL.Sync'
    end

    if GetResourceState('oxmysql') == 'started' then
        local ox = exports.oxmysql
        if ox and type(ox.fetchSync) == 'function' then
            return function(query, params)
                return ox:fetchSync(query, params or {})
            end, 'oxmysql'
        end
    end

    if GetResourceState('ghmattimysql') == 'started' then
        local ghm = exports.ghmattimysql
        if ghm and type(ghm.executeSync) == 'function' then
            return function(query, params)
                return ghm:executeSync(query, params or {})
            end, 'ghmattimysql'
        end
    end

    return nil, 'No SQL driver detected (oxmysql/ghmattimysql/mysql-async)'
end

local function createSafeSqlRunner()
    local fetcher, driverNameOrError = getSqlFetcher()
    if not fetcher then
        return nil, driverNameOrError
    end

    return function(query, params)
        local ok, result = pcall(fetcher, query, params or {})
        if not ok then
            local message = ('Database query failed via %s: %s'):format(driverNameOrError, tostring(result))
            print('^1[EC Admin] ' .. message .. '^0')
            return false, message
        end

        return true, result or {}
    end, driverNameOrError
end

local function removeMoney(playerId, moneyType, amount, reason)
    if not Framework then return false end

    local success, result = pcall(function()
        if FrameworkType == 'qbx' then
            local player = (Framework.Functions and Framework.Functions.GetPlayer and Framework.Functions.GetPlayer(playerId))
                or (Framework.GetPlayer and Framework.GetPlayer(playerId))
            if player and player.Functions and player.Functions.RemoveMoney then
                player.Functions.RemoveMoney(moneyType, amount, reason)
                return true
            end
        elseif FrameworkType == 'qb-core' then
            local player = Framework.Functions.GetPlayer(playerId)
            if player then
                player.Functions.RemoveMoney(moneyType, amount, reason)
                return true
            end
        elseif FrameworkType == 'esx' then
            local xPlayer = Framework.GetPlayerFromId(playerId)
            if xPlayer then
                if moneyType == 'cash' or moneyType == 'money' then
                    xPlayer.removeMoney(amount)
                elseif moneyType == 'bank' then
                    xPlayer.removeAccountMoney('bank', amount)
                end
                return true
            end
        end

        return false
    end)

    if not success then
        print('^1[EC Admin] Failed to remove money:^0', result)
        return false
    end

    return result == true
end

-- Transaction logger (keeps a rolling history to avoid bloat)
local function logTransaction(playerId, action, amount, moneyType, metadata)
    local entry = {
        playerId = playerId,
        identifier = getLicenseIdentifier(playerId),
        action = action,
        amount = amount,
        moneyType = moneyType,
        metadata = metadata or {},
        timestamp = os.time()
    }

    table.insert(state.transactions, 1, entry)

    -- Keep only the most recent 200 entries to limit file size
    if #state.transactions > 200 then
        for i = #state.transactions, 201, -1 do
            state.transactions[i] = nil
        end
    end

    saveState()
end

-- ============================================================================
-- MODERATION DATA (Page completely broken without this)
-- ============================================================================

lib.callback.register('ec_admin:getModerationData', function(source, data)
    print('^3[EC Admin] getModerationData callback triggered^0')

    local runQuery, driverOrError = createSafeSqlRunner()
    if not runQuery then
        local message = driverOrError .. '. Moderation data cannot be loaded.'
        print('^1[EC Admin] ' .. message .. '^0')

        return {
            success = false,
            data = {},
            error = message
        }
    end

    local function fetchModerationData(query)
        local ok, resultOrError = runQuery(query, {})
        if ok then
            return resultOrError
        end

        return {}
    end

    local bansData = {}
    local warningsData = {}
    local mutesData = {}
    local reportsData = {}

    bansData = fetchModerationData('SELECT * FROM ec_bans ORDER BY created_at DESC LIMIT 100')
    warningsData = fetchModerationData('SELECT * FROM ec_warnings ORDER BY created_at DESC LIMIT 100')
    mutesData = fetchModerationData('SELECT * FROM ec_mutes WHERE expires_at > NOW() ORDER BY created_at DESC')
    reportsData = fetchModerationData('SELECT * FROM ec_reports WHERE status != "closed" ORDER BY created_at DESC LIMIT 50')

    return {
        success = true,
        data = {
            bans = bansData,
            warnings = warningsData,
            mutes = mutesData,
            reports = reportsData
        }
    }
end)

-- ============================================================================
-- ECONOMY ACTIONS (All money management actions)
-- ============================================================================

lib.callback.register('ec_admin:setPlayerMoney', function(source, data)
    local targetId = tonumber(data.playerId)
    local moneyType = data.moneyType or 'cash'
    local amount = tonumber(data.amount) or 0
    
    print(string.format('^3[EC Admin] setPlayerMoney: Player %s, Type %s, Amount %d^0', targetId, moneyType, amount))
    
    if not targetId or not GetPlayerName(targetId) then
        return { success = false, message = 'Invalid player ID or player offline' }
    end
    
    -- Framework-specific money setting (will trigger server event)
    TriggerEvent('ec_admin:setPlayerMoney', targetId, moneyType, amount)

    logTransaction(targetId, 'set', amount, moneyType, { source = source })

    return { success = true, message = string.format('Set %s to $%d', moneyType, amount) }
end)

lib.callback.register('ec_admin:addMoney', function(source, data)
    local targetId = tonumber(data.playerId)
    local moneyType = data.moneyType or 'cash'
    local amount = tonumber(data.amount) or 0
    
    print(string.format('^3[EC Admin] addMoney: Player %s, Type %s, Amount %d^0', targetId, moneyType, amount))
    
    if not targetId or amount <= 0 then
        return { success = false, message = 'Invalid parameters' }
    end
    
    if not GetPlayerName(targetId) then
        return { success = false, message = 'Player offline' }
    end

    TriggerEvent('ec_admin:addPlayerMoney', targetId, moneyType, amount)

    logTransaction(targetId, 'add', amount, moneyType, { source = source })

    return { success = true, message = string.format('Added $%d %s', amount, moneyType) }
end)

lib.callback.register('ec_admin:removeMoney', function(source, data)
    local targetId = tonumber(data.playerId)
    local moneyType = data.moneyType or 'cash'
    local amount = tonumber(data.amount) or 0
    
    print(string.format('^3[EC Admin] removeMoney: Player %s, Type %s, Amount %d^0', targetId, moneyType, amount))
    
    if not targetId or amount <= 0 then
        return { success = false, message = 'Invalid parameters' }
    end
    
    if not GetPlayerName(targetId) then
        return { success = false, message = 'Player offline' }
    end

    TriggerEvent('ec_admin:removePlayerMoney', targetId, moneyType, amount)

    logTransaction(targetId, 'remove', amount, moneyType, { source = source })

    return { success = true, message = string.format('Removed $%d %s', amount, moneyType) }
end)

lib.callback.register('ec_admin:globalMoneyAdjustment', function(source, data)
    local moneyType = data.moneyType or 'cash'
    local adjustmentType = data.adjustmentType or 'add'
    local amount = tonumber(data.amount) or 0
    
    print(string.format('^3[EC Admin] globalMoneyAdjustment: Type %s, Adjustment %s, Amount %d^0', moneyType, adjustmentType, amount))
    
    local players = GetPlayers()
    local count = 0

    for _, playerId in ipairs(players) do
        local id = tonumber(playerId)
        if adjustmentType == 'add' then
            TriggerEvent('ec_admin:addPlayerMoney', id, moneyType, amount)
            logTransaction(id, 'global_add', amount, moneyType, { source = source })
        else
            TriggerEvent('ec_admin:removePlayerMoney', id, moneyType, amount)
            logTransaction(id, 'global_remove', amount, moneyType, { source = source })
        end
        count = count + 1
    end
    
    return { success = true, message = string.format('Global adjustment applied to %d players', count), count = count }
end)

lib.callback.register('ec_admin:wipePlayerMoney', function(source, data)
    local targetId = tonumber(data.playerId)
    
    print(string.format('^3[EC Admin] wipePlayerMoney: Player %s^0', targetId))
    
    if not targetId or not GetPlayerName(targetId) then
        return { success = false, message = 'Invalid player ID or player offline' }
    end
    
    -- Set all money types to 0
    TriggerEvent('ec_admin:setPlayerMoney', targetId, 'cash', 0)
    TriggerEvent('ec_admin:setPlayerMoney', targetId, 'bank', 0)

    logTransaction(targetId, 'wipe', 0, 'all', { source = source })

    return { success = true, message = 'Player money wiped' }
end)

lib.callback.register('ec_admin:taxPlayers', function(source, data)
    local taxRate = tonumber(data.taxRate) or 10
    local moneyType = data.moneyType or 'bank'
    
    print(string.format('^3[EC Admin] taxPlayers: Rate %d%%, Type %s^0', taxRate, moneyType))
    
    local players = GetPlayers()
    local totalCollected = 0
    local count = 0

    for _, playerId in ipairs(players) do
        local id = tonumber(playerId)
        local current = getMoney(id, moneyType)
        local taxAmount = math.floor(current * (taxRate / 100))

        if taxAmount > 0 then
            local removed = removeMoney(id, moneyType, taxAmount, 'ec_admin_tax')
            if removed then
                logTransaction(id, 'tax', taxAmount, moneyType, {
                    rate = taxRate,
                    source = source
                })
                totalCollected = totalCollected + taxAmount
            end
        end

        count = count + 1
    end

    return {
        success = true,
        message = string.format('Taxed %d players, collected $%d', count, totalCollected),
        totalCollected = totalCollected,
        playersTaxed = count
    }
end)

lib.callback.register('ec_admin:getTransactionHistory', function(source, data)
    local playerId = data.playerId or source

    print(string.format('^3[EC Admin] getTransactionHistory: Player %s^0', playerId))

    local identifier = getLicenseIdentifier(playerId)

    local transactions = {}
    for _, entry in ipairs(state.transactions) do
        if entry.identifier == identifier or entry.playerId == playerId then
            table.insert(transactions, entry)
        end
    end

    return {
        success = true,
        transactions = transactions,
        message = string.format('Found %d transactions', #transactions)
    }
end)

-- ============================================================================
-- ANTICHEAT CALLBACKS (9 missing callbacks)
-- ============================================================================

lib.callback.register('ec_admin:getDetections', function(source, data)
    print('^3[EC Admin] getDetections callback triggered^0')
    
    local detections = {}
    local success, result = pcall(function()
        return MySQL.Sync.fetchAll([[
            SELECT * FROM ec_anticheat_detections 
            WHERE status = 'pending' 
            ORDER BY created_at DESC 
            LIMIT 100
        ]], {})
    end)
    
    if success and result then
        detections = result
    end
    
    return {
        success = true,
        detections = detections
    }
end)

lib.callback.register('ec_admin:resolveDetection', function(source, data)
    local detectionId = tonumber(data.detectionId)
    local action = data.action
    
    print(string.format('^3[EC Admin] resolveDetection: ID %s, Action %s^0', detectionId, action))
    
    if not detectionId or not action then
        return { success = false, message = 'Invalid parameters' }
    end
    
    local success = pcall(function()
        MySQL.Sync.execute([[
            UPDATE ec_anticheat_detections 
            SET status = 'resolved', action_taken = ? 
            WHERE id = ?
        ]], {action, detectionId})
    end)
    
    if success then
        return { success = true, message = 'Detection resolved' }
    else
        return { success = false, message = 'Database error' }
    end
end)

lib.callback.register('ec_admin:dismissDetection', function(source, data)
    local detectionId = tonumber(data.detectionId)
    
    print(string.format('^3[EC Admin] dismissDetection: ID %s^0', detectionId))
    
    if not detectionId then
        return { success = false, message = 'Invalid detection ID' }
    end
    
    local success = pcall(function()
        MySQL.Sync.execute([[
            UPDATE ec_anticheat_detections 
            SET status = 'dismissed' 
            WHERE id = ?
        ]], {detectionId})
    end)
    
    return { success = success, message = success and 'Detection dismissed' or 'Database error' }
end)

lib.callback.register('ec_admin:escalateDetection', function(source, data)
    local detectionId = tonumber(data.detectionId)
    
    print(string.format('^3[EC Admin] escalateDetection: ID %s^0', detectionId))
    
    if not detectionId then
        return { success = false, message = 'Invalid detection ID' }
    end
    
    local success = pcall(function()
        MySQL.Sync.execute([[
            UPDATE ec_anticheat_detections 
            SET status = 'escalated', severity = 'high' 
            WHERE id = ?
        ]], {detectionId})
    end)
    
    return { success = success, message = success and 'Detection escalated' or 'Database error' }
end)

lib.callback.register('ec_admin:updateAnticheatConfig', function(source, data)
    print('^3[EC Admin] updateAnticheatConfig:^0', json.encode(data))

    state.anticheat.config = data or {}
    saveState()

    return { success = true, message = 'Config updated' }
end)

lib.callback.register('ec_admin:toggleAnticheatModule', function(source, data)
    local moduleName = data.moduleName
    local enabled = data.enabled

    print(string.format('^3[EC Admin] toggleAnticheatModule: %s = %s^0', moduleName, tostring(enabled)))

    state.anticheat.modules[moduleName] = enabled and true or false
    saveState()

    return { success = true, message = string.format('Module %s %s', moduleName, enabled and 'enabled' or 'disabled') }
end)

lib.callback.register('ec_admin:analyzePlayer', function(source, data)
    local playerId = tonumber(data.playerId)

    print(string.format('^3[EC Admin] analyzePlayer: %s^0', playerId))

    local identifier = getLicenseIdentifier(playerId)
    local flags = state.playerFlags[identifier] or {}

    local pendingDetections = {}
    local ok, result = pcall(function()
        return MySQL.Sync.fetchAll([[ 
            SELECT severity
            FROM ec_anticheat_detections
            WHERE player_identifier = ? AND status = 'pending'
        ]], { identifier })
    end)

    if ok and result then
        pendingDetections = result
    end

    local riskScore = (#flags * 5) + (#pendingDetections * 10)
    local suspicionLevel = 'low'

    if riskScore >= 50 then
        suspicionLevel = 'high'
    elseif riskScore >= 20 then
        suspicionLevel = 'medium'
    end

    return {
        success = true,
        analysis = {
            suspicionLevel = suspicionLevel,
            flags = flags,
            recentActivity = pendingDetections,
            riskScore = riskScore
        }
    }
end)

lib.callback.register('ec_admin:getPlayerFlags', function(source, data)
    local playerId = tonumber(data.playerId)

    print(string.format('^3[EC Admin] getPlayerFlags: %s^0', playerId))

    local identifier = getLicenseIdentifier(playerId)
    local flags = state.playerFlags[identifier] or {}

    return {
        success = true,
        flags = flags
    }
end)

-- ============================================================================
-- SETTINGS CALLBACKS (8 missing callbacks)
-- ============================================================================

lib.callback.register('ec_admin:saveSettings', function(source, data)
    print('^3[EC Admin] saveSettings:^0', json.encode(data))

    for category, values in pairs(data or {}) do
        state.settings[category] = values
    end

    saveState()

    return { success = true, message = 'Settings saved successfully' }
end)

lib.callback.register('ec_admin:saveWebhooks', function(source, data)
    print('^3[EC Admin] saveWebhooks:^0', json.encode(data))

    state.webhooks = data or {}
    saveState()

    return { success = true, message = 'Webhooks saved successfully' }
end)

lib.callback.register('ec_admin:testWebhook', function(source, data)
    local webhookUrl = data.webhookUrl
    
    print('^3[EC Admin] testWebhook:^0', webhookUrl)
    
    if not webhookUrl or webhookUrl == '' then
        return { success = false, message = 'Invalid webhook URL' }
    end
    
    -- Test webhook
    PerformHttpRequest(webhookUrl, function(err, text, headers)
        if err == 200 or err == 204 then
            print('^2[EC Admin] Webhook test successful^0')
        else
            print('^1[EC Admin] Webhook test failed:^0', err, text)
        end
    end, 'POST', json.encode({
        embeds = {{
            title = 'Test from EC Admin Ultimate',
            description = 'If you see this, your webhook is working!',
            color = 5814783
        }}
    }), { ['Content-Type'] = 'application/json' })
    
    return { success = true, message = 'Test webhook sent' }
end)

lib.callback.register('ec_admin:resetSettings', function(source, data)
    local category = data.category

    print('^3[EC Admin] resetSettings: Category^0', category)

    if category then
        state.settings[category] = {}
    else
        state.settings = {}
    end

    saveState()

    return { success = true, message = string.format('Reset %s settings to defaults', category or 'all') }
end)

lib.callback.register('ec_admin:getPermissions', function(source, data)
    print('^3[EC Admin] getPermissions called^0')
    
    -- TODO: Get permissions from database
    return {
        success = true,
        permissions = {}
    }
end)

lib.callback.register('ec_admin:savePermissions', function(source, data)
    print('^3[EC Admin] savePermissions:^0', json.encode(data))
    
    -- TODO: Save permissions to database
    return { success = true, message = 'Permissions saved successfully' }
end)

-- ============================================================================
-- PERFORMANCE METRICS
-- ============================================================================

lib.callback.register('ec_admin:getPerformanceMetrics', function(source)
    -- Removed spam log: print('^3[EC Admin] getPerformanceMetrics called^0')
    
    -- Basic performance metrics
    return {
        success = true,
        data = {
            cpu = 0,
            memory = collectgarbage('count') / 1024,
            network = { 
                ['in'] = 0,  -- 'in' is a Lua keyword, must be quoted
                out = 0 
            },
            frameTime = 0
        }
    }
end)

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

-- ============================================================================
-- GLOBAL TOOLS (Economy/Moderation Tools)
-- ============================================================================

lib.callback.register('ec_admin:globalToolExecute', function(source, data)
    local action = data.action
    local params = data.params or {}
    
    print(string.format('^3[EC Admin] globalToolExecute: %s^0', action))
    
    if action == 'giveAllMoney' then
        local amount = tonumber(params.amount) or 0
        local moneyType = params.moneyType or 'cash'
        local players = GetPlayers()
        local count = 0
        
        for _, playerId in ipairs(players) do
            TriggerEvent('ec_admin:addPlayerMoney', tonumber(playerId), moneyType, amount)
            count = count + 1
        end
        
        return { success = true, message = string.format('Gave $%d %s to %d players', amount, moneyType, count) }
    
    elseif action == 'healAll' then
        local players = GetPlayers()
        for _, playerId in ipairs(players) do
            TriggerClientEvent('ec_admin:heal', playerId)
        end
        return { success = true, message = 'Healed all players' }
    
    elseif action == 'reviveAll' then
        local players = GetPlayers()
        for _, playerId in ipairs(players) do
            TriggerClientEvent('ec_admin:revive', playerId)
        end
        return { success = true, message = 'Revived all players' }
    
    elseif action == 'clearInventories' then
        -- TODO: Implement clear all inventories
        return { success = true, message = 'Cleared all inventories (placeholder)' }
    
    else
        return { success = false, message = 'Unknown global tool action' }
    end
end)

-- ============================================================================
-- WHITELIST MANAGEMENT
-- ============================================================================

lib.callback.register('ec_admin:getWhitelistData', function(source, data)
    print('^3[EC Admin] getWhitelistData called^0')
    
    local whitelistData = {}
    local applicationsData = {}
    
    -- Try to fetch from database
    local success, whitelist = pcall(function()
        return MySQL.Sync.fetchAll('SELECT * FROM ec_whitelist ORDER BY created_at DESC LIMIT 100', {})
    end)
    if success then whitelistData = whitelist or {} end
    
    local success2, applications = pcall(function()
        return MySQL.Sync.fetchAll('SELECT * FROM ec_whitelist_applications WHERE status = "pending" ORDER BY created_at DESC', {})
    end)
    if success2 then applicationsData = applications or {} end
    
    return {
        success = true,
        whitelist = whitelistData,
        applications = applicationsData
    }
end)

print('^2[EC Admin] ✅ CRITICAL missing callbacks loaded successfully (26 callbacks registered)^0')