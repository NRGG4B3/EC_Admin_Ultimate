fx_version 'cerulean'
game 'gta5'

name 'EC Admin Ultimate'
description 'Comprehensive FiveM Admin Panel with NRG API Suite Integration'
author 'NRG Development'
version '1.0.0'

lua54 'yes'

-- Escrow Exemption (config should never be escrowed)
-- Host files are NOT escrowed - internal NRG use only
escrow_ignore {
    'config.lua',
    'host/**/*',
    'server/host-validation.lua'
}

-- NUI Configuration
ui_page 'ui/dist/index.html'

files {
    'ui/dist/index.html',
    'ui/dist/assets/*.js',
    'ui/dist/assets/*.css',
    'ui/dist/assets/*.png',
    'ui/dist/assets/*.jpg',
    'ui/dist/assets/*.svg',
    'ui/dist/assets/*.woff',
    'ui/dist/assets/*.woff2',
    'ui/dist/assets/*.ttf'
}

-- Dependencies (load order matters!)
dependencies {
    'ox_lib',
    'oxmysql',
    'qb-core',
    'qbx_core',
    'es_extended'
}

-- Shared configuration
shared_scripts {
    '@ox_lib/init.lua',
    'shared/framework.lua',
    'config.lua',
    'shared/utils.lua',
    'shared/vehicle-database.lua'
}

-- Server scripts (LOAD ORDER IS CRITICAL!)
server_scripts {
    '@oxmysql/lib/MySQL.lua',  -- Load MySQL first
    
    -- ==========================================
    -- CORE SERVER FILES (Load First)
    -- ==========================================
    'server/host-validation.lua',      -- Host mode validation (load FIRST)
    'server/validation-helpers.lua',  -- Input validation (load first)
    'server/rate-limiter.lua',         -- Rate limiting (load early)
    
    -- PLAYERS
    'server/players.lua',
    'server/players-callbacks.lua',
    'server/players-actions.lua',
    'server/player-profile-callbacks.lua',
    'server/player-history-tracker.lua',
    'server/players-api.lua',
    
    -- DASHBOARD
    'server/dashboard.lua',
    'server/dashboard-callbacks.lua',
    'server/dashboard-actions.lua',
    'server/dashboard-api.lua',
    
    -- REPORTS
    'server/reports.lua',
    'server/reports-callbacks.lua',  -- RE-ENABLED: Contains lib.callback.register (server-side)
    'server/reports-actions.lua',
    -- 'server/advanced-reports-callbacks.lua',  -- KEEP DISABLED: Analytics helpers only (no callbacks needed)
    
    -- ECONOMY
    'server/economy.lua',
    'server/economy-callbacks.lua',
    'server/economy-actions.lua',
    
    -- MODERATION
    'server/moderation.lua',
    'server/moderation-callbacks.lua',
    'server/moderation-actions.lua',
    
    -- MONITORING
    'server/monitoring.lua',
    'server/monitoring-callbacks.lua',
    'server/monitoring-actions.lua',
    
    -- SETTINGS
    'server/settings-callbacks-enhanced.lua',
    'server/settings-actions.lua',
    
    -- WHITELIST
    'server/whitelist.lua',
    'server/whitelist-callbacks.lua',
    'server/whitelist-actions.lua',
    'server/whitelist-advanced.lua',
    
    -- ADMIN TEAM
    'server/admin-team-manager.lua',
    'server/admin-team-migration.lua',
    'server/callbacks/admin-team-callbacks.lua',

    -- PERMISSIONS (centralized access control)
    'server/permissions.lua',
    
    -- ==========================================
    -- OTHER FEATURE MODULES (alphabetical)
    -- ==========================================
    'server/admin-abuse.lua',
    'server/admin-abuse-callbacks.lua',
    'server/admin-actions.lua',
    'server/admin-actions-server.lua',
    'server/discord-ace-integration.lua',
    'server/api-connection-manager.lua',
    'server/api-health-monitor.lua',     
    'server/api-fallback.lua',             
    'server/api-wrapper.lua',
    'server/admin-profile-callbacks.lua',  -- Admin profile system
    'server/ai-analytics.lua',
    'server/ai-analytics-callbacks.lua',
    'server/ai-detection.lua',
    'server/ai-detection-callbacks.lua',
    'server/ai-detection-api-integration.lua',
    'server/anticheat-advanced.lua',
    'server/anticheat-callbacks.lua',
    'server/api-router.lua',
    'server/backups.lua',
    'server/bans-callbacks.lua',
    'server/bans-events.lua',
    'server/cleanup.lua',
    'server/communications.lua',
    'server/community-callbacks.lua',
    'server/database-auto-setup.lua',
    'server/dev-tools-callbacks.lua',
    'server/exports.lua',
    'server/global-tools-callbacks.lua',
    'server/global-tools.lua',
    'server/events.lua',
    'server/event-handlers.lua',
    'server/global-ban-registration.lua',
    'server/global-ban-integration.lua',
    'server/host-api-connector.lua',
    'server/host.lua',
    'server/host-callbacks.lua',
    'server/host-actions.lua',
    'server/host-access-check.lua',
    'server/host-global-bans.lua',
    'server/host-webhooks.lua',
    'server/host-nrg-auth.lua',
    'server/host-management-callbacks.lua',
    'server/host-management-actions.lua',
    'server/host-dashboard-callbacks.lua',
    'host/host-revenue-callbacks.lua',
    'server/housing.lua',
    'server/housing-callbacks.lua',
    'server/housing-events.lua',
    'server/missing-callbacks.lua',
    'server/missing-callbacks-CRITICAL.lua',
    'server/inventory.lua',
    'server/inventory-callbacks.lua',
    'server/inventory-events.lua',
    'server/jobs-gangs.lua',
    'server/jobs-gangs-callbacks-complete.lua',
    'server/jobs-gangs-management.lua',
    'server/jobs-gangs-events.lua',
    'server/livemap.lua',
    'server/livemap-callbacks.lua',
    'server/live-metrics-pusher.lua',
    'server/metrics-api.lua',
    'server/metrics-sampler.lua',
    'server/owner-protection.lua',
    'server/performance.lua',
    'server/quick-actions-server-complete.lua',
    'server/resources.lua',
    'server/security.lua',
    'server/settings-callbacks-complete.lua',  -- Settings management system
    'server/system-management-callbacks.lua',
    'server/topbar-callbacks.lua',  -- RE-ENABLED: Contains lib.callback.register (server-side)
    'server/vehicle-management-api.lua',
    'server/vehicle-pack-detector.lua',
    'server/vehicles-callbacks.lua',
    'server/vehicles-events.lua',
    'server/webhooks.lua',
    'server/logging-config.lua',    -- Console message filtering
    'server/main.lua'               -- CRITICAL: Permission checks and basic events
}

-- Real-time web sync for browser access
server_script 'server/web-realtime-sync.lua'

-- Web server endpoint (customers can access via browser without Node.js!)
server_script 'server/web-server-endpoint.lua'

-- Data files
files {
    'ui/dist/**/*'
}

-- Client scripts
client_scripts {
  
    'client/startup-clean.lua',         
    'client/error-handler.lua',         
    'client/notifications.lua',         
    'client/nui-bridge.lua',            
    'client/nui-topbar.lua',            
    'client/nui-dashboard.lua',        
    'client/nui-players.lua',           
    'client/nui-player-profile.lua',
    'client/player-action-handlers.lua',  -- CRITICAL: Handles all client-side player actions
    'client/admin-menu-gating.lua',
    'client/ai-behavior-tracker.lua',     
    'client/fps-optimizer.lua',
    'client/live-data-receivers.lua',
    'client/nui-admin-abuse.lua',
    'client/nui-admin-profile.lua',
    'client/nui-ai-analytics.lua',
    'client/nui-ai-detection.lua',
    'client/nui-anticheat.lua',
    'client/nui-bans.lua',
    'client/nui-community.lua',         
    'client/nui-dev-tools.lua',         
    'client/nui-economy.lua',
    'client/nui-global-tools.lua',
    'client/host.lua',
    'client/host-callbacks.lua',
    'client/host-actions.lua',
    'client/nui-host-control.lua',
    'client/nui-host-dashboard.lua',
    'client/nui-host-management.lua',    
    'client/nui-housing.lua',
    'client/nui-inventory.lua',
    'client/nui-jobs-gangs.lua',
    'client/nui-livemap.lua',
    'client/nui-moderation.lua',        
    'client/nui-monitoring.lua',
    'client/nui-quick-actions.lua',
    'client/nui-reports.lua',
    'client/nui-settings-enhanced.lua', 
    'client/nui-system-management.lua', 
    'client/nui-vehicles.lua',
    'client/nui-whitelist.lua',         
    'client/quick-actions-handlers.lua',
    'client/quick-actions-client-complete.lua',   
    'client/global-tools-client.lua',    
    'client/topbar-actions.lua',
    'client/vehicle-management.lua',
    'client/vehicle-scanner.lua',          
    'client/vehicles-handlers.lua',      
    'client/whitelist-application.lua'
}

-- Exports
exports {
    'HasPermission',
    'EC_Perms'
}

server_exports {
    'HasPermission',
    'EC_Perms'
}
