--[[
    EC Admin Ultimate - AI Analytics NUI Callbacks (Client)
]]

-- Get AI analytics data
RegisterNUICallback('aiAnalytics:getData', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:getAIAnalytics')
    cb({ success = true })
end)

-- Export report
RegisterNUICallback('aiAnalytics:exportReport', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:exportAIReport', data)
    cb({ success = true })
end)

-- Receive AI analytics data
RegisterNetEvent('ec_admin_ultimate:client:receiveAIAnalytics', function(result)
    SendNUIMessage({
        action = 'aiAnalyticsData',
        data = result
    })
end)

-- Receive generated report
RegisterNetEvent('ec_admin_ultimate:client:aiReportGenerated', function(result)
    SendNUIMessage({
        action = 'aiReportGenerated',
        data = result
    })
end)

print('[EC Admin] AI Analytics NUI callbacks loaded')
