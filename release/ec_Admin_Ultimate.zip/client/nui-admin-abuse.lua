--[[
    EC Admin Ultimate - Admin Abuse NUI Callbacks (CLIENT)
]]

print('[EC Admin] 👁️ Admin Abuse tracking NUI callbacks loading...')

RegisterNUICallback('getAdminAbuse', function(data, cb)
    local success, result = pcall(function()
        return lib.callback.await('ec_admin:getAdminAbuse', false, data)
    end)
    
    if success and result then
        cb(result)
    else
        cb({ success = false, logs = {}, stats = {} })
    end
end)

print('[EC Admin] ✅ Admin Abuse tracking NUI callbacks loaded')
