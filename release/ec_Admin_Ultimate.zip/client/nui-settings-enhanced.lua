--[[
    EC Admin Ultimate - Enhanced Settings NUI Callbacks (Client)
]]

-- Get settings
RegisterNUICallback('settings:getData', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:getSettings')
    cb({ success = true })
end)

-- Save settings
RegisterNUICallback('settings:save', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:saveSettings', data)
    cb({ success = true })
end)

-- Save webhooks
RegisterNUICallback('settings:saveWebhooks', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:saveWebhooks', data)
    cb({ success = true })
end)

-- Test webhook
RegisterNUICallback('settings:testWebhook', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:testWebhook', data)
    cb({ success = true })
end)

-- Reset settings
RegisterNUICallback('settings:reset', function(data, cb)
    TriggerServerEvent('ec_admin_ultimate:server:resetSettings', data)
    cb({ success = true })
end)

-- Receive settings data
RegisterNetEvent('ec_admin_ultimate:client:receiveSettings', function(result)
    SendNUIMessage({
        action = 'settingsData',
        data = result
    })
end)

-- Receive settings response
RegisterNetEvent('ec_admin_ultimate:client:settingsResponse', function(result)
    SendNUIMessage({
        action = 'settingsResponse',
        data = result
    })
end)

print('[EC Admin] Enhanced Settings NUI callbacks loaded')
