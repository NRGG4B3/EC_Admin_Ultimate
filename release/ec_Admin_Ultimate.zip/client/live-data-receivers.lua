--[[
    EC Admin Ultimate - Live Data Receivers
    
    Client-side handlers for real-time data updates from server
    Ensures complete front-to-back connectivity with live data
]]--

print('[EC Admin] 📡 Loading Live Data Receivers...')

-- Helper function to send data to NUI
local function SendNUIData(action, data)
    SendNUIMessage({
        action = action,
        data = data
    })
end

--[[ ==================== DATA RECEIVERS ==================== ]]--

-- Receive Player List from Server
RegisterNetEvent('ec-admin:receivePlayerList')
AddEventHandler('ec-admin:receivePlayerList', function(players)
    print('[EC Admin] Received player list: ' .. #players .. ' players')
    SendNUIData('updatePlayerList', players)
end)

-- Receive Player Details from Server
RegisterNetEvent('ec-admin:receivePlayerDetails')
AddEventHandler('ec-admin:receivePlayerDetails', function(details)
    print('[EC Admin] Received player details')
    SendNUIData('updatePlayerDetails', details)
end)

-- Receive Vehicle List from Server
RegisterNetEvent('ec-admin:receiveVehicleList')
AddEventHandler('ec-admin:receiveVehicleList', function(vehicles)
    print('[EC Admin] Received vehicle list: ' .. #vehicles .. ' vehicles')
    SendNUIData('updateVehicleList', vehicles)
end)

-- Receive Ban List from Server
RegisterNetEvent('ec-admin:receiveBanList')
AddEventHandler('ec-admin:receiveBanList', function(bans)
    print('[EC Admin] Received ban list: ' .. #bans .. ' bans')
    SendNUIData('updateBanList', bans)
end)

-- Receive Warning List from Server
RegisterNetEvent('ec-admin:receiveWarningList')
AddEventHandler('ec-admin:receiveWarningList', function(warnings)
    print('[EC Admin] Received warning list: ' .. #warnings .. ' warnings')
    SendNUIData('updateWarningList', warnings)
end)

-- Receive Resource List from Server
RegisterNetEvent('ec-admin:receiveResourceList')
AddEventHandler('ec-admin:receiveResourceList', function(resources)
    print('[EC Admin] Received resource list: ' .. #resources .. ' resources')
    SendNUIData('updateResourceList', resources)
end)

-- Receive Log List from Server
RegisterNetEvent('ec-admin:receiveLogList')
AddEventHandler('ec-admin:receiveLogList', function(logs)
    print('[EC Admin] Received log list: ' .. #logs .. ' logs')
    SendNUIData('updateLogList', logs)
end)

-- Receive Backup List from Server
RegisterNetEvent('ec-admin:receiveBackupList')
AddEventHandler('ec-admin:receiveBackupList', function(backups)
    print('[EC Admin] Received backup list: ' .. #backups .. ' backups')
    SendNUIData('updateBackupList', backups)
end)

-- Receive Server Metrics from Server
RegisterNetEvent('ec-admin:receiveServerMetrics')
AddEventHandler('ec-admin:receiveServerMetrics', function(metrics)
    SendNUIData('updateServerMetrics', metrics)
end)

--[[ ==================== NOTIFICATIONS ==================== ]]--

-- Receive Notifications from Server
RegisterNetEvent('ec-admin:notify')
AddEventHandler('ec-admin:notify', function(type, message)
    SendNUIData('showNotification', {
        type = type,
        message = message
    })
    
    -- Also show in chat/console for visibility
    if type == 'error' then
        print('^1[EC Admin] Error: ^7' .. message)
    elseif type == 'success' then
        print('^2[EC Admin] Success: ^7' .. message)
    elseif type == 'warning' then
        print('^3[EC Admin] Warning: ^7' .. message)
    else
        print('^5[EC Admin] Info: ^7' .. message)
    end
end)

--[[ ==================== AUTO-REFRESH ==================== ]]--

-- Auto-refresh request from server
RegisterNetEvent('ec-admin:requestRefresh')
AddEventHandler('ec-admin:requestRefresh', function()
    -- Only refresh if menu is open
    if GetResourceState('EC_admin_ultimate') == 'started' then
        -- Check if NUI is focused
        local isMenuOpen = exports['EC_admin_ultimate']:isMenuOpen()
        
        if isMenuOpen then
            -- Refresh all data
            TriggerServerEvent('ec-admin:getPlayers')
            TriggerServerEvent('ec-admin:getServerMetrics')
        end
    end
end)

--[[ ==================== WORLD SYNC ==================== ]]--

-- Weather sync from server
RegisterNetEvent('ec-admin:syncWeather')
AddEventHandler('ec-admin:syncWeather', function(weather)
    SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather)
    SetWeatherTypePersist(weather)
    print('[EC Admin] Weather synced: ' .. weather)
end)

-- Time sync from server
RegisterNetEvent('ec-admin:syncTime')
AddEventHandler('ec-admin:syncTime', function(hour, minute)
    -- Set time for all clients
    NetworkOverrideClockTime(hour, minute, 0)
    
    SendNUIData('timeSync', {
        hour = hour,
        minute = minute
    })
end)

-- ============================================================================
-- LIVE METRICS UPDATE (Critical for Dashboard)
-- ============================================================================

-- Receive live metrics update from server
RegisterNetEvent('ec-admin:updateLiveData')
AddEventHandler('ec-admin:updateLiveData', function(data)
    SendNUIMessage({
        action = 'updateLiveMetrics',
        data = data
    })
end)

-- Legacy compatibility (old event name)
RegisterNetEvent('ec-admin:updateMetrics')
AddEventHandler('ec-admin:updateMetrics', function(metrics)
    SendNUIMessage({
        action = 'updateLiveMetrics',
        data = metrics
    })
end)

-- ============================================================================
-- SPECTATE SYSTEM
-- ============================================================================

local isSpectating = false
local spectateTarget = nil

-- Start spectate
RegisterNetEvent('ec-admin:startSpectate')
AddEventHandler('ec-admin:startSpectate', function(targetId)
    local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
    
    if DoesEntityExist(targetPed) then
        isSpectating = true
        spectateTarget = targetPed
        
        NetworkSetInSpectatorMode(true, targetPed)
        
        SendNUIData('showNotification', {
            type = 'info',
            message = 'Spectating player. Press ESC to stop.'
        })
        
        print('[EC Admin] Started spectating player')
    else
        SendNUIData('showNotification', {
            type = 'error',
            message = 'Could not find target player'
        })
    end
end)

-- Stop spectate (ESC key)
Citizen.CreateThread(function()
    while true do
        if isSpectating then
            Citizen.Wait(0) -- Check frequently when spectating
            
            if IsControlJustPressed(0, 322) then -- ESC key
                NetworkSetInSpectatorMode(false, spectateTarget)
                isSpectating = false
                spectateTarget = nil
                
                SendNUIData('showNotification', {
                    type = 'info',
                    message = 'Stopped spectating'
                })
                
                print('[EC Admin] Stopped spectating')
            end
        else
            Citizen.Wait(1000) -- Sleep when not spectating
        end
    end
end)

--[[ ==================== LIVE DATA PUSH ==================== ]]--

-- Push live player position updates to NUI
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5000) -- Every 5 seconds
        
        -- Only if menu is open (get from nui-bridge export)
        local success, isMenuOpen = pcall(function()
            return exports['EC_admin_ultimate']:isMenuOpen()
        end)
        
        if success and isMenuOpen then
            local playerPed = PlayerPedId()
            local coords = GetEntityCoords(playerPed)
            local heading = GetEntityHeading(playerPed)
            
            SendNUIData('updatePlayerPosition', {
                x = coords.x,
                y = coords.y,
                z = coords.z,
                heading = heading
            })
        end
    end
end)

--[[ ==================== EXPORTS ==================== ]]--

-- Export menu state (returns false if export doesn't exist yet)
function IsMenuOpen()
    return false -- This file doesn't track menu state, nui-bridge.lua does
end

exports('isMenuOpen', IsMenuOpen)

--[[ ==================== CLEANUP HANDLERS ==================== ]]--

-- Stop spectating a specific target (when they disconnect)
RegisterNetEvent('ec_admin:stopSpectatingTarget', function(targetId)
    if isSpectating and spectateTarget == GetPlayerPed(GetPlayerFromServerId(targetId)) then
        NetworkSetInSpectatorMode(false, spectateTarget)
        isSpectating = false
        spectateTarget = nil
        
        SendNUIData('showNotification', {
            type = 'info',
            message = 'Player you were spectating has disconnected'
        })
        
        print('[EC Admin] Stopped spectating - target disconnected')
    end
end)

-- Force close everything (resource stop)
RegisterNetEvent('ec_admin:forceCloseAll', function()
    -- Close NUI
    SendNUIMessage({ action = 'forceClose' })
    SetNuiFocus(false, false)
    
    -- Stop spectating
    if isSpectating then
        NetworkSetInSpectatorMode(false, spectateTarget)
        isSpectating = false
        spectateTarget = nil
    end
    
    print('[EC Admin] Force closed all UI and spectating')
end)

-- General cleanup event
RegisterNetEvent('ec_admin:cleanup', function()
    -- Stop spectating
    if isSpectating then
        NetworkSetInSpectatorMode(false, spectateTarget)
        isSpectating = false
        spectateTarget = nil
    end
    
    -- Unfreeze local player
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, false)
    
    -- Clear invincibility
    SetEntityInvincible(ped, false)
    
    print('[EC Admin] Cleanup complete')
end)

print('[EC Admin] ✅ Live Data Receivers loaded with cleanup handlers')